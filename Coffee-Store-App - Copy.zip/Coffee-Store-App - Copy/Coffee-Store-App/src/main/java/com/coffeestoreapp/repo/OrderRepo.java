package com.coffeestoreapp.repo;

import com.coffeestoreapp.model.Order;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface OrderRepo extends JpaRepository<Order, Long> {
    List<Order> findByEmail(String email);
}