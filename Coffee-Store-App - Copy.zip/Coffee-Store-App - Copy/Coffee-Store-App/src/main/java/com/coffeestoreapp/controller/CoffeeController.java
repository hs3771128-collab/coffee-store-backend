package com.coffeestoreapp.controller;

import com.coffeestoreapp.model.Coffee;
import com.coffeestoreapp.service.CoffeeService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/coffees")
@CrossOrigin("*")
public class CoffeeController {

    private final CoffeeService coffeeService;

    public CoffeeController(CoffeeService coffeeService) {
        this.coffeeService = coffeeService;
    }

    // 1. Mood Matcher Endpoint
    // Example: /api/coffees/mood/coding
    @GetMapping("/mood/{vibe}")
    public List<Coffee> getByMood(@PathVariable String vibe) {
        return coffeeService.getCoffeesByMood(vibe);
    }

    // 2. Featured/Best Sellers for Home Page
    @GetMapping("/best-sellers")
    public List<Coffee> getBestSellers() {
        return coffeeService.getBestSellers();
    }

    @GetMapping
    public List<Coffee> getAll() {
        return coffeeService.getAllCoffees();
    }

    @PostMapping
    public Coffee addCoffee(@RequestBody Coffee coffee) {
        return coffeeService.saveCoffee(coffee);
    }
}