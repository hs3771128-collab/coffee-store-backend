package com.coffeestoreapp.service;

import com.coffeestoreapp.model.Order;
import com.coffeestoreapp.repo.OrderRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class OrderService {

    private final OrderRepo orderRepository;

    @Autowired
    public OrderService(OrderRepo orderRepository) {
        this.orderRepository = orderRepository;
    }

    // 1. Naya Order Place karne ke liye
    public Order placeOrder(Order order) {
        // Agar status pehle se set nahi hai, toh PENDING rakho
        if (order.getStatus() == null || order.getStatus().isEmpty()) {
            order.setStatus("PENDING");
        }
        return orderRepository.save(order);
    }

    // 2. Sare Orders dekhne ke liye (Sirf Admin ke liye)
    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    // 3. Kisi khas Customer ke orders dekhne ke liye (Email se search)
    public List<Order> getOrdersByEmail(String email) {
        return orderRepository.findByEmail(email);
    }

    // 4. Single Order ki details dekhne ke liye
    public Optional<Order> getOrderById(Long id) {
        return orderRepository.findById(id);
    }

    // 5. Order ka Status update karne ke liye (e.g. Pending -> Shipped)
    public Order updateOrderStatus(Long id, String status) {
        return orderRepository.findById(id).map(order -> {
            order.setStatus(status);
            return orderRepository.save(order);
        }).orElseThrow(() -> new RuntimeException("Order nahi mila id: " + id));
    }

    // 6. Order delete karne ke liye
    public void deleteOrder(Long id) {
        orderRepository.deleteById(id);
    }
}