package com.coffeestoreapp.service;

import com.coffeestoreapp.model.Coffee;
import com.coffeestoreapp.repo.CoffeeRepo;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class CoffeeService {

    private final CoffeeRepo coffeeRepository;

    public CoffeeService(CoffeeRepo coffeeRepository) {
        this.coffeeRepository = coffeeRepository;
    }

    // Saari coffees
    public List<Coffee> getAllCoffees() { return coffeeRepository.findAll(); }

    // Mood Matcher Logic
    public List<Coffee> getCoffeesByMood(String mood) {
        return coffeeRepository.findByVibeIgnoreCase(mood);
    }

    // Front page Best Sellers
    public List<Coffee> getBestSellers() {
        return coffeeRepository.findByIsBestSellerTrue();
    }

    public Coffee saveCoffee(Coffee coffee) {
        return coffeeRepository.save(coffee);
    }
}