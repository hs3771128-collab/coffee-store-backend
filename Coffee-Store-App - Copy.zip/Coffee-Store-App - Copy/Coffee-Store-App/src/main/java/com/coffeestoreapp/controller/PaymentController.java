package com.coffeestoreapp.controller;

import com.coffeestoreapp.model.Order;
import com.coffeestoreapp.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/payment")
@CrossOrigin("*")
public class PaymentController {

    @Autowired
    private OrderService orderService;

    // 1. Order Place karne ka endpoint (COD aur Online dono ke liye)
    @PostMapping("/place")
    public ResponseEntity<Order> createOrder(@RequestBody Order order) {
        // Unique Scenario: Status set karna
        if ("COD".equalsIgnoreCase(order.getPaymentMethod())) {
            order.setStatus("PENDING_DELIVERY");
        } else {
            order.setStatus("AWAITING_PAYMENT");
        }

        Order savedOrder = orderService.placeOrder(order);
        return ResponseEntity.ok(savedOrder);
    }

    // 2. Simple Payment Verification (Stripe ke baghair)
    @PostMapping("/verify")
    public Map<String, String> verifyPayment(@RequestBody Map<String, Object> data) {
        Map<String, String> response = new HashMap<>();

        // Yahan hum NextJS ko batayenge ke order confirm ho gaya
        response.put("message", "Order Received Successfully!");
        response.put("status", "success");

        return response;
    }
}