package com.coffeestoreapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoffeeStoreAppApplication {

    public static void main(String[] args) {
        SpringApplication.run ( CoffeeStoreAppApplication.class, args );
    }

}
