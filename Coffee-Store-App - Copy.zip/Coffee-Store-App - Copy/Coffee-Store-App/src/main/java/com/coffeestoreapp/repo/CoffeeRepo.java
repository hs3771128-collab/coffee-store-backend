package com.coffeestoreapp.repo;

import com.coffeestoreapp.model.Coffee;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CoffeeRepo extends JpaRepository<Coffee, Long> {

    // Mood/Vibe ke hisab se search
    List<Coffee> findByVibeIgnoreCase(String vibe);

    // Sirf Best Sellers dikhane ke liye
    List<Coffee> findByIsBestSellerTrue();

    // Roast level (Light/Dark) ke liye
    List<Coffee> findByRoastLevel(String roast);
}